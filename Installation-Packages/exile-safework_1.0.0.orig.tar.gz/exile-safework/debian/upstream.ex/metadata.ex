# Example file for upstream/metadata.
# See https://wiki.debian.org/UpstreamMetadata for more info/fields.
# Below an example based on a github project.

# Bug-Database: https://github.com/<user>/exile/issues
# Bug-Submit: https://github.com/<user>/exile/issues/new
# Changelog: https://github.com/<user>/exile/blob/master/CHANGES
# Documentation: https://github.com/<user>/exile/wiki
# Repository-Browse: https://github.com/<user>/exile
# Repository: https://github.com/<user>/exile.git
