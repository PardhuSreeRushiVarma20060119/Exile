Document: exile
Title: Debian exile Manual
Author: <insert document author here>
Abstract: This manual describes what exile is
 and how it can be used to
 manage online manuals on Debian systems.
Section: unknown

Format: debiandoc-sgml
Files: /usr/share/doc/exile/exile.sgml.gz

Format: postscript
Files: /usr/share/doc/exile/exile.ps.gz

Format: text
Files: /usr/share/doc/exile/exile.text.gz

Format: HTML
Index: /usr/share/doc/exile/html/index.html
Files: /usr/share/doc/exile/html/*.html
